﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Develore.GDiff
{
	internal class DiffBlock
	{
		public byte[] Data { get; set; }
		public long SourceIndex { get; set; }
		public string StrongHashString { get; private set; }
		private byte[] _StrongHash;
		public byte[] StrongHash
		{
			get { return _StrongHash; }
			set
			{
				_StrongHash = value;
				this.StrongHashString = BitConverter.ToString(_StrongHash).Replace("-", "");
			}
		}
		public string WeakHashString { get; private set; }
		private byte[] _WeakHash;
		public byte[] WeakHash
		{
			get { return _WeakHash; }
			set
			{
				_WeakHash = value;
				this.WeakHashString = BitConverter.ToString(_WeakHash).Replace("-", "");
			}
		}
	}
}
