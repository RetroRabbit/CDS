﻿using Develore.GDiff;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Comparison
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCompair_Click(object sender, EventArgs e)
        {
            if (File.Exists(txtDelta.Text))
                File.Delete(txtDelta.Text);

            using (FileStream swDelta = new FileStream(txtDelta.Text, FileMode.CreateNew))
            {
                using (FileStream srBase = new FileStream(txtBase.Text, FileMode.Open))
                {
                    using (FileStream srNew = new FileStream(txtNew.Text, FileMode.Open))
                    {
                        MemoryStream s = new MemoryStream();
                        GDiff.Compute(srBase, srNew, s);

                        s.Position = 0;
                        swDelta.Write(s.GetBuffer(), 0, (int)s.Length);
                        swDelta.Close(); 
                    }
                }
            }
        }

        private void btnMerge_Click(object sender, EventArgs e)
        {
            using (FileStream swResult = new FileStream(txtResult.Text, FileMode.CreateNew))
            {
                using (FileStream swDelta = new FileStream(txtDelta.Text, FileMode.Open))
                {
                    using (FileStream srApply = new FileStream(txtApplyTo.Text, FileMode.Open))
                    {
                        GDiff.Apply(swDelta, srApply, swResult);
                        swResult.Close();
                    }
                }
            }
        }
    }
}
