﻿namespace Comparison
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCompair = new System.Windows.Forms.Button();
            this.btnMerge = new System.Windows.Forms.Button();
            this.txtBase = new System.Windows.Forms.TextBox();
            this.txtNew = new System.Windows.Forms.TextBox();
            this.txtApplyTo = new System.Windows.Forms.TextBox();
            this.txtDelta = new System.Windows.Forms.TextBox();
            this.lblBase = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCompair
            // 
            this.btnCompair.Location = new System.Drawing.Point(189, 164);
            this.btnCompair.Name = "btnCompair";
            this.btnCompair.Size = new System.Drawing.Size(75, 23);
            this.btnCompair.TabIndex = 0;
            this.btnCompair.Text = "Compair";
            this.btnCompair.UseVisualStyleBackColor = true;
            this.btnCompair.Click += new System.EventHandler(this.btnCompair_Click);
            // 
            // btnMerge
            // 
            this.btnMerge.Location = new System.Drawing.Point(189, 194);
            this.btnMerge.Name = "btnMerge";
            this.btnMerge.Size = new System.Drawing.Size(75, 23);
            this.btnMerge.TabIndex = 1;
            this.btnMerge.Text = "Merge";
            this.btnMerge.UseVisualStyleBackColor = true;
            this.btnMerge.Click += new System.EventHandler(this.btnMerge_Click);
            // 
            // txtBase
            // 
            this.txtBase.Location = new System.Drawing.Point(103, 12);
            this.txtBase.Name = "txtBase";
            this.txtBase.Size = new System.Drawing.Size(285, 20);
            this.txtBase.TabIndex = 2;
            this.txtBase.Text = "D:\\Data\\CDS.Client.BusinessLayer_Base.dll";
            // 
            // txtNew
            // 
            this.txtNew.Location = new System.Drawing.Point(103, 39);
            this.txtNew.Name = "txtNew";
            this.txtNew.Size = new System.Drawing.Size(285, 20);
            this.txtNew.TabIndex = 3;
            this.txtNew.Text = "D:\\Data\\CDS.Client.BusinessLayer_New.dll";
            // 
            // txtApplyTo
            // 
            this.txtApplyTo.Location = new System.Drawing.Point(103, 66);
            this.txtApplyTo.Name = "txtApplyTo";
            this.txtApplyTo.Size = new System.Drawing.Size(285, 20);
            this.txtApplyTo.TabIndex = 4;
            this.txtApplyTo.Text = "D:\\Data\\CDS.Client.BusinessLayer_Apply_to.dll";
            // 
            // txtDelta
            // 
            this.txtDelta.Location = new System.Drawing.Point(103, 94);
            this.txtDelta.Name = "txtDelta";
            this.txtDelta.Size = new System.Drawing.Size(285, 20);
            this.txtDelta.TabIndex = 3;
            this.txtDelta.Text = "D:\\Data\\CDS.Client.BusinessLayer_Delta.gdiff";
            // 
            // lblBase
            // 
            this.lblBase.AutoSize = true;
            this.lblBase.Location = new System.Drawing.Point(12, 15);
            this.lblBase.Name = "lblBase";
            this.lblBase.Size = new System.Drawing.Size(31, 13);
            this.lblBase.TabIndex = 5;
            this.lblBase.Text = "Base";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "New";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "ApplyTo";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 97);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Delta";
            // 
            // txtResult
            // 
            this.txtResult.Location = new System.Drawing.Point(103, 120);
            this.txtResult.Name = "txtResult";
            this.txtResult.Size = new System.Drawing.Size(285, 20);
            this.txtResult.TabIndex = 3;
            this.txtResult.Text = "D:\\Data\\CDS.Client.BusinessLayer_Result.dll";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 123);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Result";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(476, 224);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblBase);
            this.Controls.Add(this.txtApplyTo);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.txtDelta);
            this.Controls.Add(this.txtNew);
            this.Controls.Add(this.txtBase);
            this.Controls.Add(this.btnMerge);
            this.Controls.Add(this.btnCompair);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCompair;
        private System.Windows.Forms.Button btnMerge;
        private System.Windows.Forms.TextBox txtBase;
        private System.Windows.Forms.TextBox txtNew;
        private System.Windows.Forms.TextBox txtApplyTo;
        private System.Windows.Forms.TextBox txtDelta;
        private System.Windows.Forms.Label lblBase;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtResult;
        private System.Windows.Forms.Label label1;
    }
}

